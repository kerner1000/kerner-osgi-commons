java -Xmx1024m -jar plugins/org.eclipse.osgi_3.4.0.v20080605-1900.jar -clean
